function distance = pdist2(island1, island2)
distance = [];
for t1 = 1:length(island1)
    for t2 = 1:length(island2)
        distance(t1,t2) = sqrt((island1(t1) - island2(t2))^2);    
    end
end

return