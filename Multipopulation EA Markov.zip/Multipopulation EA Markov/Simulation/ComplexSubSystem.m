function [PopCount, optimalcount] = ComplexSubSystem(OPTIONS, Population, Result)

[Sub1Cost, Sub2Cost] = ComplexSubSystemCostFunction;
SubCost = {Sub1Cost, Sub2Cost};
[PopCount, optimalcount] = GAGUR(SubCost,OPTIONS,Population);




return




