function [PopDistribution, Pops, optimalcount] = GAGURComplex(ProblemFunction, DisplayFlag, ProbFlag, RandSeed)



if ~exist('DisplayFlag', 'var')
    DisplayFlag = true;
end
if ~exist('ProbFlag', 'var')
    ProbFlag = false;
end
if ~exist('RandSeed', 'var')
    RandSeed = round(sum(100*clock));
end


[OPTIONS, Result, MainLevel, SubLevel, Population] = Init(DisplayFlag, ProblemFunction);%, RandSeed);


RoundIndicator = 0;
while RoundIndicator < OPTIONS.MainLevelMaxgen
    
    [PopDistribution, Pops, optimalcount] = MainLevel(OPTIONS, Result, SubLevel, Population);
    RoundIndicator = RoundIndicator + 1;
    
end


return
