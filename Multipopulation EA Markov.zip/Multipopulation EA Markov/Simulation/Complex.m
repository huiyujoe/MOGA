function [InitFunction, MainLevel, SubLevel] = Complex

InitFunction = @ComplexInit;
MainLevel = @ComplexMainLevel;
SubLevel = @ComplexSubSystem;


return;


function [Population, OPTIONS, Result] = ComplexInit(OPTIONS)

Range = [0, 1; 0, 1];
ParameterSubsystem = {[1,2], [1,2]};
ConstraintIndex = 0;
CostIndex = {[1,2],[3,4]};
NumSubsystem = 2;


for SubSystemIndex = 1:NumSubsystem
    ParameterInUse = ParameterSubsystem{SubSystemIndex};
    Population1 = [];   
    for popindex = 1 : OPTIONS.popsize
        chrom = round((Range(ParameterInUse,2) - Range(ParameterInUse,1))'.*rand(1,length(ParameterInUse)) + Range(ParameterInUse,1)');
        Population1(popindex).chrom = chrom;
        Population1(popindex).SubSystemID = SubSystemIndex;
        
    end
    Population{SubSystemIndex} = Population1;
end


  
SetPoint = (Range(:,2) - Range(:,1))'.*rand(1,length(Range(:,1))) + Range(:,1)';

OPTIONS.OrderDependent = false;
OPTIONS.Range = Range;
OPTIONS.SetPoint = SetPoint;
OPTIONS.InitialIndicator = 1;
OPTIONS.StopIndicator = 0;
OPTIONS.ParameterSubsystem = ParameterSubsystem;
OPTIONS.ConstraintIndex = ConstraintIndex;
OPTIONS.CostIndex = CostIndex;
OPTIONS.NumSubsystem = NumSubsystem;

Result = [];
return;


function  [PopDistribution, Pops, optimalcount] = ComplexMainLevel(OPTIONS, Result, SubLevel, Population)

[PopCount, optimalcount] = SubLevel(OPTIONS, Population, Result);
n = 4;
N = 4;
Islands = [0 0; 0 1; 1 0; 1 1];

% q = log(n) / log(2); % number of SIVs per island
% Islands = zeros(N, q);
% for i = 1 : n
%     temp = i - 1;
%     for j = q-1 : -1 : 0
%         if temp >= 2^j
%             Islands(i,q-j) = 1;
%             temp = temp - 2^j;
%         end
%     end
% end

NumPossibleSingle = nchoosek(n+N-1, N);
NumPossible = nchoosek(n+N-1, N)^2; 
TempPops = EnumPops(n, N);

Pops = [];
for t1 = 1:NumPossibleSingle
    for t2 = 1:NumPossibleSingle
        Pops = [Pops; TempPops(t1,:), TempPops(t2,:)];
    end
end

[row, ~] = size(Pops);
PopDistribution = zeros(1,row);

[row,~] = size(PopCount);
for t = 1:row
    [~,index]= ismember(PopCount(t,:), Pops, 'rows');
    PopDistribution(index) = PopDistribution(index) + 1;
end




return


