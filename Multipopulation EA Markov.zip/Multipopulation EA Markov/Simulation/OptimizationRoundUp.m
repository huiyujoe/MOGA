function OptimizationRoundUp(ResultDic)

if ~exist('ResultDic', 'var')
    ResultDic = pwd;
end

NumMonteCarlo = 5;
TotalPopDistribution = [];

tic
for t = 1:NumMonteCarlo
    disp(['Simulation ', num2str(t) ' of ', num2str(NumMonteCarlo)])
    [PopDistribution, Pops, optimalcount] = GAGURComplex(@Complex);
    TotalPopDistribution = [TotalPopDistribution; PopDistribution];
    
    if t == 1
       totaloptimalcount = optimalcount;
    else
        totaloptimalcount = totaloptimalcount + optimalcount;
    end
end
toc

totaloptimalcount = totaloptimalcount / t;

[row, ~] = size(TotalPopDistribution);
TotalPopDistribution = sum(TotalPopDistribution,1) / row;


[TotalPopDistribution, index] = sort(PopDistribution, 'descend');
[row, ~] = size(Pops);
PopsSave = Pops;

for t = 1:row
Pops(t,:) = PopsSave(index(t),:);
end


TotalPopDistribution = TotalPopDistribution / sum(TotalPopDistribution);


PlotAndStore(TotalPopDistribution, Pops, ResultDic);

plot(1:length(totaloptimalcount(1,:)), totaloptimalcount(1,:), 'red');
hold on
plot(1:length(totaloptimalcount(1,:)), totaloptimalcount(2,:));
plot(1:length(totaloptimalcount(1,:)), totaloptimalcount(3,:));

hold off

return






function PlotAndStore(TotalPopDistribution, Pops,  ResultDic)
save([ResultDic,'/Percentage.mat'],'TotalPopDistribution', 'Pops');
for t = 1:5
disp(['Population = ', num2str(Pops(t,:)), ' Probability = ', num2str(TotalPopDistribution(t))]);
end
return

