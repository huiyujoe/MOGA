function [Sub1Cost, Sub2Cost] = ComplexSubSystemCostFunction

Sub1Cost = @ComplexSub1;
Sub2Cost = @ComplexSub2;

return;


function Population = ComplexSub1(Population, OPTIONS)

for t = 1:OPTIONS.popsize
    %%%% CostFunction
    Chrom = Population(t).chrom;
    Population(t).cost(1) =  2*Chrom(1) + Chrom(2) + 1;
    Population(t).cost(2) =  Population(t).cost(1) / (Chrom(1) + Chrom(2) + 1) + 1;
end

return




function Population = ComplexSub2(Population, OPTIONS)

for t = 1:OPTIONS.popsize
    %%%% CostFunction
    Chrom = Population(t).chrom;
    Population(t).cost(1) =  2*Chrom(1) + Chrom(2) + 1;
    Population(t).cost(2) =  Population(t).cost(1) / (Chrom(1) + Chrom(2) + 1) + 1;
end

return


