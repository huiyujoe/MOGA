function [OPTIONS, Result, MainLevel, SubLevel, Population] = Init(DisplayFlag, ProblemFunction)

OPTIONS.popsize = 4; 
OPTIONS.MainLevelMaxgen = 1; 
OPTIONS.GAMaxgen = 5000;
OPTIONS.pmutate = 0.01; 
OPTIONS.DisplayFlag = DisplayFlag;
OPTIONS.ProblemFunction = ProblemFunction; 
[InitFunction, MainLevel, SubLevel] = ProblemFunction();
[Population, OPTIONS, Result] = InitFunction(OPTIONS);

return;