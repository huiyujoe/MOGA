function    [Population,Result] = Elitism(Result, Population, OPTIONS, StopIndicator)

if StopIndicator == 0
    Result.ElitismResult = Result.Main;
    Result.ElitismChrom = Result.Chrom;
    Result.ElitismFeasible = Result.FeasibleIndicator;
    for t = 1:OPTIONS.NumSubsystem
        TempPop = Population{t};
        TempPop(1).chrom = Result.Chrom(OPTIONS.ParameterSubsystem{t});
        Population{t} = TempPop;
    end
else
    [Choice] = NonDomSorting(Result);
    if Choice == 2
        Result.Main = Result.ElitismResult;
        Result.Chrom = Result.ElitismChrom;
        Result.FeasibleIndicator = Result.ElitismFeasible;
        for t = 1:OPTIONS.NumSubsystem
            TempPop = Population{t};
            TempPop(1).chrom = Result.Chrom(OPTIONS.ParameterSubsystem{t});
            Population{t} = TempPop;
        end
    else
        Result.ElitismResult = Result.Main;
        Result.ElitismChrom = Result.Chrom;
        Result.ElitismFeasible = Result.FeasibleIndicator;
        
        for t = 1:OPTIONS.NumSubsystem
            TempPop = Population{t};
            TempPop(1).chrom = Result.Chrom(OPTIONS.ParameterSubsystem{t});
            Population{t} = TempPop;
        end
    end
    
end
return


function [Choice] = NonDomSorting(Result)
Result1 = Result.Main;
Result2 = Result.ElitismResult;

Rank = zeros(1,numel(Result1));
for t = 1:numel(Result1)
    if Result1(t) > Result2(t)
        Rank(1) = Rank(1) + 1;
    elseif Result2(t) > Result1(t)
        Rank(2) = Rank(2) + 1;
    end
end

if Result.FeasibleIndicator <= Result.ElitismFeasible
    if Result.FeasibleIndicator == Result.ElitismFeasible
        if Rank(2) > Rank(1)
            Choice = 1;
        else
            Choice = 2;
        end
    else
        Choice =1;
    end
else
    Choice = 2;
end
return