
function [PopCount, optimalcount] = GAGUR(SubCost,OPTIONS,Population)
% For further reading, please refer to other's papers of the author: 
% the analysis of biogeography-based complex system optimization, 
% which provides the relationship of multipopulation with complex multi-system, 
% and the equicalences and differences of evolutionary algorithms including
% genetic algorithms and biogeography-based optimization.

PopSize = OPTIONS.popsize;
Possibleind = 0;
PredeterminedRank = RankCalc;

for t = 1:OPTIONS.NumSubsystem
    CostFunction = SubCost{t};
    [Population{t}] = CostFunction(Population{t}, OPTIONS);
    [Population{t}, Rank{t}] = SortPopulation (Population{t}, OPTIONS, t, PredeterminedRank);
    Possibleind = Possibleind + 2^length(OPTIONS.ParameterSubsystem{t});
end
PopCount = zeros(OPTIONS.GAMaxgen, Possibleind);

optimalcount = zeros(3,OPTIONS.GAMaxgen);
currentcount = zeros(3,1);


for t1 = 1:OPTIONS.GAMaxgen
    for t = 1:OPTIONS.NumSubsystem
        if t == 1
         SubSystemRE{t} = Rank{t} / max(PredeterminedRank(1:4));
%            SubSystemRE{t} = 1;
           SubSystemRI{t} = 1 - Rank{t} / max(PredeterminedRank(1:4));
        else
         SubSystemRE{t} = Rank{t} / max(PredeterminedRank(5:8));  
%            SubSystemRE{t} = 1;
           SubSystemRI{t} = 1 - Rank{t} / max(PredeterminedRank(5:8));
        end
    end
    PreSavePopulation = Population;
    
    for t = 1:OPTIONS.NumSubsystem
        RI = SubSystemRI{t};
        RE = SubSystemRE{t};
        PopulationSub = Population{t};
        SavePopulation = PopulationSub;
        ChromLength = length(PopulationSub(1).chrom);
        
        for t3 = 1:PopSize
            for t4 = 1:ChromLength
%                 if rand < RI(t3)
                    EmigrationIsland = RouletteWheel(RE);
                    PopulationSub(t3).chrom(t4) =  SavePopulation(EmigrationIsland).chrom(t4);
%                 end
            end
        end
        Population{t} = PopulationSub;
    end

    for t7 = 1:OPTIONS.NumSubsystem
        for t8 = 1:OPTIONS.NumSubsystem
            PopulationSub1 = Population{t7};
            PopulationSub2 = PreSavePopulation{t8};
            if t7 ~= t8
                Population{t7} = CrossoverSubsystem(PopulationSub1, PopulationSub2, OPTIONS, SubSystemRI{t7});
            end
        end
    end
        
    for t7 = 1:OPTIONS.NumSubsystem
        PopulationSub = Population{t7};
        ChromLength = length(PopulationSub(1).chrom);
        Range = OPTIONS.Range;
        Range = Range(OPTIONS.ParameterSubsystem{PopulationSub(1).SubSystemID},:);
        for t5 = 1:PopSize
            for t6 = 1:ChromLength
                if rand < OPTIONS.pmutate
                    if PopulationSub(t5).chrom(t6) == 1
                    PopulationSub(t5).chrom(t6) =  0;
                    else
                    PopulationSub(t5).chrom(t6) =  1;
                    end       
                end
            end
        end
        Population{t7} = PopulationSub;
    end

    
    for t = 1:OPTIONS.NumSubsystem
        CostFunction = SubCost{t};
        [Population{t}] = CostFunction(Population{t}, OPTIONS);
        [Population{t}, Rank{t}] = SortPopulation (Population{t}, OPTIONS, t, PredeterminedRank);
    end
    
    
    
    for t = 1:OPTIONS.NumSubsystem
        for t3 = 1:length(Population{t})
            if t == 1
                
                if isequal(Population{t}(t3).chrom, [0,0])
                    PopCount(t1,1) = PopCount(t1,1) + 1;
                end
                if isequal(Population{t}(t3).chrom, [0,1])
                    PopCount(t1,2) = PopCount(t1,2) + 1;
                end
                
                if isequal(Population{t}(t3).chrom, [1,0])
                    PopCount(t1,3) = PopCount(t1,3) + 1;
                end
                if isequal(Population{t}(t3).chrom, [1,1])
                    PopCount(t1,4) = PopCount(t1,4) + 1;
                end
                
            else
                
                if isequal(Population{t}(t3).chrom, [0,0])
                    PopCount(t1,5) = PopCount(t1,5) + 1;
                end
                if isequal(Population{t}(t3).chrom, [0,1])
                    PopCount(t1,6) = PopCount(t1,6) + 1;
                end
                if isequal(Population{t}(t3).chrom, [1,0])
                    PopCount(t1,7) = PopCount(t1,7) + 1;
                end
                if isequal(Population{t}(t3).chrom, [1,1])
                    PopCount(t1,8) = PopCount(t1,8) + 1;
                end
            end
        end
    end

    
    
    if isequal(PopCount(t1,:), [4 0 0 0 4 0 0 0])
        currentcount(1) = currentcount(1) + 1;
        optimalcount(1, t1) = currentcount(1) / t1;
    else
        optimalcount(1, t1) = currentcount(1) / t1;
    end
    
    
    if isequal(PopCount(t1,:), [3 1 0 0 4 0 0 0])
        currentcount(2) = currentcount(2) + 1;
        optimalcount(2, t1) = currentcount(2) / t1;
    else
        optimalcount(2, t1) = currentcount(2) / t1;
    end
    
    
    if isequal(PopCount(t1,:), [4 0 0 0 3 1 0 0])
        currentcount(3) = currentcount(3) + 1;
        optimalcount(3, t1) = currentcount(3) / t1;
    else
        optimalcount(3, t1) = currentcount(3) / t1;
    end
    
    
end


return

function  [Population,SortedRank] = SortPopulation (Population, OPTIONS, t, PredeterminedRank)
Rank = zeros(1,OPTIONS.popsize);

if t == 1
    for t1 = 1:OPTIONS.popsize
        if isequal(Population(t1).chrom, [0,0])
            Rank(t1) = PredeterminedRank(1);
        end
        if isequal(Population(t1).chrom, [0,1])
            Rank(t1) = PredeterminedRank(2);
        end
        if isequal(Population(t1).chrom, [1,0])
            Rank(t1) = PredeterminedRank(3);
        end
        if isequal(Population(t1).chrom, [1,1])
            Rank(t1) = PredeterminedRank(4);
        end
    end
else
    for t1 = 1:OPTIONS.popsize
        if isequal(Population(t1).chrom, [0,0])
            Rank(t1) = PredeterminedRank(5);
        end
        if isequal(Population(t1).chrom, [0,1])
            Rank(t1) = PredeterminedRank(6);
        end
        if isequal(Population(t1).chrom, [1,0])
            Rank(t1) = PredeterminedRank(7);
        end
        if isequal(Population(t1).chrom, [1,1])
            Rank(t1) = PredeterminedRank(8);
        end
    end
end

[SortedRank,loc] = sort(Rank);
TempPopulation = Population;
for t = 1:OPTIONS.popsize
    Population(t) = TempPopulation(loc(t));
end
return



function [Population] = CrossoverSubsystem(SubPopulation1, SubPopulation2, OPTIONS, RI)

[ParameterInCommonIndex,ParameterInCommonIndex1,ParameterInCommonIndex2] = intersect(OPTIONS.ParameterSubsystem{SubPopulation1(1).SubSystemID}, OPTIONS.ParameterSubsystem{SubPopulation2(1).SubSystemID});
ParameterInCommon = numel(ParameterInCommonIndex);


Chrom1=[];
Chrom2=[];
for t1 = 1:OPTIONS.popsize
    Chrom1(t1,:) = SubPopulation1(t1).chrom;
    Chrom2(t1,:) = SubPopulation2(t1).chrom;
end
Chrom1Temp = Chrom1(:,ParameterInCommonIndex1);
Chrom2Temp = Chrom2(:,ParameterInCommonIndex2);
Chrom1Save = Chrom1Temp;
Chrom2Save = Chrom2Temp;
Distance = pdist2(Chrom1Temp,Chrom2Temp);
for t1 = 1:OPTIONS.popsize
    for t2 = 1:ParameterInCommon
         if rand < RI(t1)
            if sum(Distance(t1,:)) > 0
               [loc] = islandfinder(Distance(t1,:));
            else
               loc = t1; 
            end
            Chrom1Temp(t1,t2) = Chrom2Save(loc,t2);
         end
    end
end


if exist('Chrom1')
    Chrom1(:,ParameterInCommonIndex1) = Chrom1Temp;
    for t1 = 1:OPTIONS.popsize
        SubPopulation1(t1).chrom = Chrom1(t1,:);
    end
end

Population = SubPopulation1;
return

function EmigrationIsland = RouletteWheel(RE)
RandomNum = rand;
RWProb = 0;
for t = 1:length(RE)
    RWProb = RWProb + RE(t) / sum(RE);
    if RandomNum <= RWProb
        EmigrationIsland = t;
        break;
    end
end
return


function PredeterminedRank = RankCalc
n = 4;
N = 4;

Islands = [0 0; 0 1; 1 0; 1 1];
Islands1 = [0 0; 0 1; 1 0; 1 1];
Islands2 = [0 0; 0 1; 1 0; 1 1];
% q = log(n) / log(2); % number of SIVs per island
% Islands = zeros(N, q);
% for i = 1 : n
%     temp = i - 1;
%     for j = q-1 : -1 : 0
%         if temp >= 2^j
%             Islands(i,q-j) = 1;
%             temp = temp - 2^j;
%         end
%     end
% end
% Islands1 = [Islands, NaN(length(Islands(:,1)),1)];
% Islands2 = [Islands(:,1), NaN(length(Islands(:,1)),1),Islands(:,2)];



cost11 = Islands1(:,1) * 2 + Islands1(:,2) + 1;
cost12 = cost11 ./ (Islands1(:,1) + Islands1(:,2) + 1) + 1;

cost21 = Islands2(:,1) * 2 + Islands2(:,2) + 1;
cost22 = cost21 ./ (Islands2(:,1) + Islands2(:,2) + 1) + 1;



mu1 = ones(1,n);
mu2 = ones(1,n);
for t1 = 1:n
    for t2 = t1+1:n
        if cost11(t1) < cost11(t2)
            mu1(t1) = mu1(t1) + 1;
        else
            if cost11(t2) < cost11(t1)
                mu1(t2) = mu1(t2) + 1;
            end
        end
        
        if cost12(t1) < cost12(t2)
            mu1(t1) = mu1(t1) + 1;
        else
            if cost12(t2) < cost12(t1)
                mu1(t2) = mu1(t2) + 1;
            end
        end
        
        if cost21(t1) < cost21(t2)
            mu2(t1) = mu2(t1) + 1;
        else
            if cost21(t2) < cost21(t1)
                mu2(t2) = mu2(t2) + 1;
            end
        end
        if cost22(t1) < cost22(t2)
            mu2(t1) = mu2(t1) + 1;
        else
            if cost22(t2) < cost22(t1)
                mu2(t2) = mu2(t2) + 1;
            end
        end
    end
end

PredeterminedRank = [mu1, mu2];

return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function  [loc] = islandfinder(Distance)

randnum = rand * sum(Distance);
sumdistance = 0;
for t = 1:length(Distance)
    sumdistance = sumdistance + Distance(t);
    if randnum <= sumdistance
        loc = t;
        break;
    end
end
return