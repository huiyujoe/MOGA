function Jk=arraypad(matrix,padsize,padvalue)
%Code is compatible with 2D arrays only!
%
% function Jk=arraypad(matrix,padsize,padvalue)
%
%Inputs:
%matrix: Matrix to be padded
%padsize: vector specifying the amount to be padded in each dimension. IE: [3,0] will pad 3 rows to a 2D array
%padvalue: default to 0, pass a number to pad with instead of 0
%
%Default Direction: 'post' => arraypad will append the array with padvalue
%
%To be used with:
%created J is max(nvec) by m
%J should be n by m
%pad with 0's:
%Jk=arraypad(Jk,[n-max(nvec),0]);

%Default value
if ~exist('padvalue', 'var')
    padvalue=0;
end    

%Check to see if correct number of parameters have been passed
if nargin < 2 || nargin > 3
	disp('Error: Unexpected amount of parameters passed to Arraypad')
end

%Check to see if the padsize dimension matches with the matrix dims:
if length(size(matrix)) ~= length(padsize)
	disp('Error: Arraypad requires padsize and matrix dimensins to match')
end

%Multi-D
% for i=1:length(padsize) %dim index
% [r,c]=size(matrix);
% p=padsize(i) %dim value
% cat(i,matrix,padvalue+zeros(p))
% end

%Add rows
[r,c]=size(matrix);
d=padsize(1); 
p=padvalue+zeros(d,c);
matrix=[matrix;p];
%Add columns
[r,c]=size(matrix);
d=padsize(2); 
p=padvalue+zeros(r,d);
matrix=[matrix,p];

Jk=matrix;
  
return