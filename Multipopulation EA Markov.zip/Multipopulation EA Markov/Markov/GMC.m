function [Prob]=GMC(ProbMatrix, nvec)

% Generalized Multinominal Distribution:
% [Prob]=GeneralizedMultinominal(ProbMatrix, nvec)
%
% This function calculates the Generalized Multinominal Distribution based
% on the formula given in:
% Norman Beaulieu's "On the Generalized Multinominal Distribution, Optimal Multinominal Detectors, and Generalized Weighted Partial Decision Detectors"
%
% Consider a random experiment, E, and suppose it has m possible outcomes:
%A1, A2, ..., Am.
% Now, suppose P(Ai)=pi for all i, and pi can change for each independent
%repetition of E.
% Suppose A1 occurs N1 times, A2 occurs N2 times, ..., Am occurs Nm times.
% This function calculates the probability of P(N1=n1, N2=n2, ..., Nm=nm)
%
%Inputs:
%+ProbMatrix is n by m. Each row lists probablity for a trial:
% Trial            P(each 1xm)
%   1              (1/6, 1/6,...)
%   2              (2/6, 3/6,...)
%  ...             ...
%   n              (6/6, 0/6,...)
%
%+nvec is 1 by m:
%Lists the m possible outcomes for a trial.
%nvec=[1,3,0,1,0] means outcome i will occur nvec(i) times.
%
% ~Memo
% 9/15/08
%%

% error(nargchk(2, 2, nargin)) %Check if the correct number of parameters have been passed

%%
%Check for user input / dimension errors and calculate n,m:
% n = # of trials and is the rows of P and sum of (nvec)
% m = # of possible outcomes for each trial (ie 6 for a die) and cols of (ProbMatrix) and cols of (nvec)
% and ideally nvec is 1xm and ProbMatrix is nxm.
[h,nvec,ProbMatrix,n,m]=CheckForErrors(nvec,ProbMatrix);
nvec; ProbMatrix;
%%
%Find the number of possible combinations
Sp=1;
for i=1:length(nvec) %or m
    Sp=Sp*factorial(nvec(i));
end
Sp=factorial(n)/Sp;

%%
%This function creates the matrix J.
%J lists the existance of all possible outcomes for all trials
[J] = CreateJ(n, m, nvec, Sp);

%%
%Apply the generalized multinominal distribution formula
Prob=0;
for d=1:Sp %for each of the sigma possibilities
    p=1;
    for i=1:n
        k=1;
        for y=1:m
            k=k*(ProbMatrix(i,y)^J(i,y,d)); %Calculate each P^J at each i
        end
        p=p*k; %product of Pij's at each i
    end
    Prob=Prob+p; %Sum for each sigma
end
if Prob > 1 | Prob < 0
    err=('oh, oh. Prob is unrealistic');
    disp(err)
    h=finish(err);
end

%if no errors found display result
if h == 0
    Prob;
else
    %in case of error, return -1
    Prob = -1;
end

% END OF MAIN

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [h,nvec,ProbMatrix,n,m]=CheckForErrors(nvec,ProbMatrix)
%Check for errors in inital conditions and user input

h=0; %error handle init
n=sum(nvec); %number of trials
m=length(nvec); %number of possible outcomes

%Check errors on given probabilites:
[Pr,Pc]=size(ProbMatrix);
%1) Each row must add to 1, with some tolerance:
for i=1:Pr
    r=sum(ProbMatrix(i,:));
    if r<0.998 | r>1.002
        err=('Error: Each row of ProbMatrix should add to 1');
        disp(err)
        h=finish(err);
    end
end

%2) Sum of elements of nvec must be <= row(ProbMatrix)
if (n <= Pr) ~= 1
    err=('Error: Sum of elements of nvec must be <= row(ProbMatrix)');
    disp(err)
    h=finish(err);
end

%3) Number of elements in nvec must be <= col(ProbMatrix)
if (length(nonzeros(nvec)) <= Pc) ~= 1
    err=('Error: Number of elements in nvec must be <= col(ProbMatrix)');
    disp(err)
    h=finish(err);
end

%Note: We are not allowing the don't care condition for:
%n cannot set to be > sum(nvec)
%for example:
% n=4; %number of trials and m=4; %number of possible outcomes
% nvec=[1,1,0,1]; %outcome i will occur nvec(i) times.
% Sum of nvec = 3, so we don't care about which outcome happens at the last trial.
% if sum(nvec) > n
%     err=('Error: Number of trials cannot be less than sum of outcomes');
%     disp(err)
%     h=finish(err);
% end
%
% if length(nvec) ~= m
%     err=('Error: Number of possible outcomes does not match outcome expectaitons matrix, N');
%     disp(err)
%     h=finish(err);
% end

%Calculate n and m:
% n = # of trials and is the rows of P and sum of (nvec)
% m = # of possible outcomes for each trial (ie 6 for a die) and cols of (ProbMatrix) and cols of (nvec)
% and ideally nvec is 1xm and ProbMatrix is nxm.
%
% however, how should the code interpret the n and m if the nvec and ProbMatrix dimensions do not match?
% see:
%
% case 1) rows of P > sum of (nvec)
% nvec=[1,1,2,0]  and ProbMatrix is 5x4
% ProbMatrix=[0.2,0.3,0.5,0;
%     0.1,0.1,0.7,0.1;
%     0.2,0.4,0.2,0.2;
%     0.1,0.3,0.1,0.5;
%     0.3,0.1,0.2,0.4]
% In this case, is n 4 or 5?
% Since each trial is independent, it makes sense to me to ignore  the last row of ProbMatrix since nvec is only defined for 4 trials:
% ProbMatrix2=[0.2,0.3,0.5,0;
%     0.1,0.1,0.7,0.1;
%     0.2,0.4,0.2,0.2;
%     0.1,0.3,0.1,0.5]
if Pr > sum(nvec)
    ProbMatrix=ProbMatrix(1:sum(nvec),:);
    disp('Warning: Ignoring extra trials.')
end
%
% case 2) cols of (ProbMatrix) > cols of (nvec)
% This is a trickier case.
% nvec=[1,2,0]  and ProbMatrix is 5x4
% ProbMatrix=[0.2,0.3,0.5,0;
%     0.1,0.1,0.7,0.1;
%     0.2,0.4,0.2,0.2;
%     0.1,0.3,0.1,0.5;
%     0.3,0.1,0.2,0.4]
% What should m be in this case? nvec lists 3 possible outcomes yet the ProbMatrix has another column. Should I pad the nvec with another col/outcome that is equal to zero:
% nvec2=[1,2,0,0]
if Pc > length(nvec)
    nvec=arraypad(nvec,[0,Pc-length(nvec)]);
    disp('Warning: Padding with improbable outcomes.')
end

%Update
n=sum(nvec); %number of trials
m=length(nvec); %number of possible outcomes

return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [J] = CreateJ(n, m, nvec, Sp)
%This function creates the matrix J.
%J lists all possible outcomes for all trials
%J will be a n by m matrix with Sp many dimensions
%J matrix will be used like a look-up table.
%It tells if the corresponding probability, Pij, will be used,1, or not, 0.
%Rules: Sum of each col =1 and sum of each row = 1

%%
%create the Jk matrix. Jk will be the base matrix for permutations
Jk=[];
for i=1:length(nvec) %or m
    if nvec(i) > 0
        nn=nvec(i);
        for ii = 1 : nn
            Jk(ii,i) = 1;
        end
    else
        Jk(1,i) = 0;
    end
end
%created J is max(nvec) by m
%J should be n by m
%pad with 0's:
% Jk=padarray(Jk,[n-max(nvec),0],0,'post');
Jk=arraypad(Jk,[n-max(nvec),0]); %use the homebrew funct
% Jk

%%
%Create a Row template
R=zeros(n,m);
Rrow=1; %init row counter
for i=1:m
    for j=1:nvec(i)
    R(Rrow,i)=1;
    Rrow=Rrow+1;
    end
end
if isequal([n,m],size(R)) ~= 1
      err=('Error: Problem creating the R matrix');
    disp(err)
    h=finish(err);
end

%Find permuations of indices
Rowindex=[1:n];
RowIndices=perms(Rowindex);

%Created J matrices based on permuted indices
% J=zeros(n,m,Sp); %init 
%We have a lot of repeated indices. Try to reduce that later
Jrepeated=zeros(n,m,factorial(n)); %init
for i =1:factorial(n)
    Jrow=1;
    for j=1:n
        Jrepeated(Jrow,:,i)=R(RowIndices(i,j),:);
        Jrow=Jrow+1;
    end
end %for i

%Deleted repeated matrices
J=zeros(n,m,Sp); %init
in=1;
for i=1:factorial(n)
    for j=i+1:factorial(n)
        if isequal(Jrepeated(:,:,i),Jrepeated(:,:,j))
            break; %Has a match, skip compare
        end
        if j == factorial(n) %looked at all J's
        %Unique, keep it
        J(:,:,in)=Jrepeated(:,:,i);
        in=in+1;
        end
    end
end
%Last one is Unique, keep it
J(:,:,in)=Jrepeated(:,:,i);

return %end of CreateJJ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
function [h]=finish(err)
%Create an informational pop-up on error
h=errordlg(err,'Multinominal Distribution Error');
%Save and ask for exit on error
% button = questdlg([err,'.  Ready to quit?'], ...
%     'Exit Dialog','Yes','No','No');
% switch button
%     case 'Yes',
%         disp('Exiting MATLAB');
%         %Save variables to matlab.mat
%         save
%     case 'No',
%         quit cancel;
% end
return