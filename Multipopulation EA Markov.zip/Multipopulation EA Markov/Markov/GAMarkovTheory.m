function GAMarkovTheory(pm, n, N)
if ~exist('pm', 'var')
    pm = 0.01;
end
if ~exist('n', 'var')   
    n = 4;
end
if ~exist('N', 'var')    
    N = 4;
end

q = log(n) / log(2); 
Islands = [0 0; 0 1; 1 0; 1 1];
% Islands = zeros(N, q);
% for i = 1 : n
%     temp = i - 1;
%     for j = q-1 : -1 : 0
%         if temp >= 2^j
%             Islands(i,q-j) = 1;
%             temp = temp - 2^j;
%         end
%     end
% end

NumPossibleSingle = nchoosek(n+N-1, N);
NumPossible = nchoosek(n+N-1, N)^2; 


Q = ones(NumPossible, NumPossible);

TempPops = EnumPops(n, N);
Pops1 = TempPops;
Pops2 = TempPops;

Pops = [];
for t1 = 1:NumPossibleSingle
    for t2 = 1:NumPossibleSingle
        Pops = [Pops; TempPops(t1,:), TempPops(t2,:)];
    end
end


Islands1 = [0 0; 0 1; 1 0; 1 1];
Islands2 = [0 0; 0 1; 1 0; 1 1];

cost11 = Islands1(:,1) * 2 + Islands1(:,2) + 1;
cost12 = cost11 ./ (Islands1(:,1) + Islands1(:,2) + 1) + 1;

cost21 = Islands2(:,1) * 2 + Islands2(:,2)+1;
cost22 = cost21 ./ (Islands2(:,1) + Islands2(:,2) + 1) + 1;



mu1 = ones(1,n);
mu2 = ones(1,n);
for t1 = 1:n
    for t2 = t1+1:n
        if cost11(t1) < cost11(t2)
            mu1(t1) = mu1(t1) + 1;
        else
            if cost11(t2) < cost11(t1)
                mu1(t2) = mu1(t2) + 1;
            end
        end
        
        if cost12(t1) < cost12(t2)
            mu1(t1) = mu1(t1) + 1;
        else
            if cost12(t2) < cost12(t1)
                mu1(t2) = mu1(t2) + 1;
            end
        end
        
        if cost21(t1) < cost21(t2)
            mu2(t1) = mu2(t1) + 1;
        else
            if cost21(t2) < cost21(t1)
                mu2(t2) = mu2(t2) + 1;
            end
        end
        if cost22(t1) < cost22(t2)
            mu2(t1) = mu2(t1) + 1;
        else
            if cost22(t2) < cost22(t1)
                mu2(t2) = mu2(t2) + 1;
            end
        end
    end
end

mu1 =  mu1'/max(mu1);
mu2 =  mu2'/max(mu2);



M1 = zeros(n, n);
M2 = zeros(n, n);

for i = 1 : n
    for j = 1 : n
        numbitschange = 0;
        for k = 1:q
            temp = abs(Islands1(i,k) - Islands1(j,k));
            if ~isnan(temp)
                numbitschange = numbitschange + temp;
            end
        end
        M1(i,j) = pm^numbitschange * (1-pm)^(q-numbitschange);
    end
end

for i = 1 : n
    for j = 1 : n
        numbitschange = 0;
        for k = 1:q
            temp = abs(Islands2(i,k) - Islands2(j,k));
            if ~isnan(temp)
                numbitschange = numbitschange + temp;
            end
        end
        M2(i,j) = pm^numbitschange * (1-pm)^(q-numbitschange);
        M2(j,i) = M2(i,j);
    end
end




disp([num2str(NumPossible), 'possible population distributions']);


distanceMatrix1 = DistanceCalculation(Islands1, Islands2);
distanceMatrix2 = DistanceCalculation(Islands2, Islands1);
% distanceMatrix1 = zeros(4,4);
% distanceMatrix2 = DistanceCalculation(Islands2, Islands1);


for z = 1 : NumPossible
    
    fprintf('.');
    if mod(z,85) == 0, fprintf('\n'); end
       
  % Subpopulation 1 %
    
    TotalMu11 = sum(Pops(z,1:n) .* mu1'); 
    Pijk1 = ones(N, n); 
    
    for trial = 1 : N 
        vsum = 0;
        for i = 1 : n
            vsum = vsum + Pops(z,i);
            if vsum >= trial
                m = i;
                break;
            end
        end
        
        
        for island = 1 : n 
            for s = 1 : q 
                jset = [];
                if ~isnan(Islands1(island,s))
                    for j = 1 : n
                        if Islands1(j,s) == Islands1(island,s)
                            jset = [jset j];
                        end                      
                    end
                    
                    factor = (1-mu1(m)) * (Pops(z,jset) * mu1(jset)) / TotalMu11;
                    if Islands1(m,s) == Islands1(island,s)
                        factor = factor + mu1(m);
                    end
                    Pijk1(trial,island) = Pijk1(trial,island) * factor;
                end
            end
        end
        
        
    end
    
    
    P1 = crosssubprobability(Islands1, Islands2, distanceMatrix1, Pops, Pijk1, M1, N, n, q, z, mu1, 1);

        
    % Subpopulation 2 %
    TotalMu21 = sum(Pops(z,n+1:end) .* mu2'); 
    Pijk2 = ones(N, n); 
    
    for trial = 1 : N 
        vsum = 0;
        for i = n+1 : 2*n
            vsum = vsum + Pops(z,i);
            if vsum >= trial
                m = i;
                break;
            end
        end
        m = m - n;
        
        for island = 1 : n 
%           for s = 1 : q+1 % for each SIV per island
            for s = 1 : q 
                jset = [];
                if ~isnan(Islands2(island,s))
                    for j = 1 : n
                        if Islands2(j,s) == Islands2(island,s)
                            jset = [jset j];
                        end
                        
                    end
                    
                    factor = (1-mu2(m)) * (Pops(z,jset + n) * mu2(jset)) / TotalMu21;
                    if Islands2(m,s) == Islands2(island,s)
                        factor = factor + mu2(m);
                    end
                    Pijk2(trial,island) = Pijk2(trial,island) * factor;
                end
            end
        end
        
        
    end
    
    
    P2 = crosssubprobability(Islands2, Islands1, distanceMatrix2, Pops, Pijk2, M2, N, n, q, z, mu2, 2);
    
    
    
    for k = 1 : NumPossibleSingle
        Q1(k) = GMC(P1, Pops1(k,:));
        if Q1(k) < 0, return, end
    end
    
    for k = 1 : NumPossibleSingle
        Q2(k) = GMC(P2, Pops2(k,:));
        if Q2(k) < 0, return, end
    end
    
    
    QCount = 1;
    for k1 = 1 : NumPossibleSingle
        for k2 = 1 : NumPossibleSingle
            Q(QCount,z) = Q1(k1)*Q2(k2);
            QCount = QCount + 1;
        end
    end    
end


denom = 0;
for u = 1 : NumPossible
    Qu = Q;
    Qu(:,u) = 0;
    denom = denom + det(Qu - eye(size(Qu)));
end
for v = 1 : NumPossible
    Qv = Q;
    Qv(:,v) = 0;
    qv(v) = det(Qv - eye(size(Qv))) / denom;
end

fprintf('\n');

[y, ndx] = sort(qv, 'descend');

for t = 1:5
    display(['Prob(', num2str(Pops(ndx(t),:)), ') = ', num2str(y(t))]);
end

PopsSave = Pops;
for t = 1:length(y)
    Pops(t,:) = PopsSave(ndx(t),:);
end
save([pwd,'/result.mat'],'y', 'Pops');


function P = crosssubprobability(Islands1, Islands2, distanceMatrix, Pops, Pijk, M, N, n, q, z, mu, subsystemindex)

Pikl1 = ones(N, n); 

for t1 = 1 : n    
    for t2 = 1:n
%       for s = 1 : q+1 % for each SIV per island
        for s = 1 : q
            jset = [];
            if ~isnan(Islands1(t2,s))
                if ~isnan(Islands2(t2,s))   
                    for j = 1 : n
                        if Islands2(j,s) == Islands1(t2,s)
                            if subsystemindex == 1
                                jset = [jset j+n];
                            else
                                jset = [jset j];
                            end
                        end
                        
                    end
                    
                    if subsystemindex == 1
                        TotalMu12 = sum(Pops(z,n+1:end).* distanceMatrix(t1,:));
                    else
                        TotalMu12 = sum(Pops(z,1:n).* distanceMatrix(t1,:));   
                    end
                    
                    if TotalMu12 == 0  
                        if Islands1(t2,s) == Islands1(t1,s)
                            factor = 1 - mu(t1);
                        else
                            factor = 0;
                        end
                        
                    else
                        if subsystemindex == 1
                            
                            factor = (1- mu(t1)) * sum(Pops(z,jset) .* distanceMatrix(t1,(jset-n))) / TotalMu12;
                        else
                            factor = (1- mu(t1)) * sum(Pops(z,jset) .* distanceMatrix(t1,(jset))) / TotalMu12;
                            
                        end
                    end

                    
                    if Islands1(t2,s) == Islands1(t1,s)
                        factor = factor + mu(t1);
                    end
                    Pikl1(t1,t2) = Pikl1(t1,t2) * factor;
                    
                else   
                    
                    if Islands1(t2,s) == Islands1(t1,s);
                        factor = 1;
                        
                    else
                        factor = 0;
                        
                    end
                    
                    Pikl1(t1,t2) = Pikl1(t1,t2) * factor;
                end
            end
        end
    end
end

[nrow, ncol] = size(Pijk);
tempPijk1 = zeros(nrow, ncol);
for t1 = 1:nrow
    for t2 = 1:ncol
        tempPijk1(t1,t2) = Pijk(t1, :) * Pikl1(:, t2);
    end
end
Pijk = tempPijk1;

P = Pijk * M; 

return



function  matrix = DistanceCalculation(Islands1,Islands2)

[nrow1, ncol1] = size(Islands1);
[nrow2, ~] = size(Islands2);
matrix = [];
for t1 = 1:nrow1
    for t2 = 1:nrow2
        temparray = (Islands1(t1,:) - Islands2(t2,:)).^2;
        tempresult = 0;
        for t3 = 1:length(temparray)
            if ~isnan(temparray(t3))
                tempresult = tempresult + temparray(t3);
            end
        end
        matrix(t1,t2) = sqrt(tempresult);
    end
end



return


